#ifndef HEHEPIG_OPENFILE_MANAGER_H
#define HEHEPIG_OPENFILE_MANAGER_H


// 记录了一个打开文件
class File {

public:
    enum FileFlags {
        FREAD   = 0x1,
        FWRITE  = 0x2
    };

public:
    int     f_flag;
    int     f_count;
    int     f_ino;      // 指向的内存Inode下标
    int     f_offset;
};


// 记录了一个进程打开的文件
// 保存在 User 结构中
class OpenFiles {
    
};



#endif