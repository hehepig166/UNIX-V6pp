/*
 * 全局定义。
 * 2051565 龚天遥
 * 创建于 2022年8月1日。
 */

#pragma once

/** 结构体紧凑。 */
#ifndef __packed
    #define __packed __attribute__((packed))
#endif


